# Bluetooth Earphone Scroller - Android App

This is an Android application that provides system-wide scrolling functionality using Bluetooth earphone buttons. The app can overlay other applications and inject scroll events based on earphone button presses.

## Project Structure
- Android Kotlin application
- Requires system overlay permissions
- Uses accessibility services for scroll injection
- Implements Bluetooth media button detection
- Foreground service for continuous operation

## Key Features
- System-wide overlay capability
- Bluetooth earphone button detection
- Scroll injection via accessibility service
- Configurable settings interface
- Runtime permission handling

## Development Guidelines
- Target Android API 30+ for modern overlay permissions
- Use proper service lifecycle management
- Handle runtime permissions gracefully
- Implement proper Bluetooth button filtering
- Follow accessibility service best practices