package com.scrollerapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
// import com.scrollerapp.databinding.ActivityMainBinding
import com.scrollerapp.service.OverlayService

class MainActivity : AppCompatActivity() {
    
    companion object {
        private const val REQUEST_OVERLAY_PERMISSION = 1001
        private const val REQUEST_NOTIFICATION_PERMISSION = 1002
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        setupUI()
        checkPermissions()
    }
    
    private fun setupUI() {
        findViewById<Button>(R.id.btnStartService).setOnClickListener {
            if (checkAllPermissions()) {
                startScrollerService()
            } else {
                requestMissingPermissions()
            }
        }
        
        findViewById<Button>(R.id.btnStopService).setOnClickListener {
            stopScrollerService()
        }
        
        findViewById<Button>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        
        findViewById<Button>(R.id.btnPermissions).setOnClickListener {
            requestMissingPermissions()
        }
        
        findViewById<Button>(R.id.btnAccessibilitySettings).setOnClickListener {
            openAccessibilitySettings()
        }
    }
    
    private fun checkPermissions() {
        updatePermissionStatus()
    }
    
    private fun updatePermissionStatus() {
        val hasOverlayPermission = Settings.canDrawOverlays(this)
        val hasNotificationPermission = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS) == 
                    android.content.pm.PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
        
        findViewById<TextView>(R.id.tvOverlayPermission).text = if (hasOverlayPermission) "✓ Granted" else "✗ Required"
        findViewById<TextView>(R.id.tvNotificationPermission).text = if (hasNotificationPermission) "✓ Granted" else "✗ Required"
        findViewById<TextView>(R.id.tvAccessibilityPermission).text = "⚠ Check manually in settings"
        
        findViewById<Button>(R.id.btnStartService).isEnabled = hasOverlayPermission && hasNotificationPermission
    }
    
    private fun checkAllPermissions(): Boolean {
        val hasOverlayPermission = Settings.canDrawOverlays(this)
        val hasNotificationPermission = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS) == 
                    android.content.pm.PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
        
        return hasOverlayPermission && hasNotificationPermission
    }
    
    private fun requestMissingPermissions() {
        // Request overlay permission
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).apply {
                data = Uri.parse("package:$packageName")
            }
            startActivityForResult(intent, REQUEST_OVERLAY_PERMISSION)
            return
        }
        
        // Request notification permission (Android 13+)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS) 
                != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(
                    this, 
                    arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 
                    REQUEST_NOTIFICATION_PERMISSION
                )
                return
            }
        }
    }
    
    private fun openAccessibilitySettings() {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        startActivity(intent)
        Toast.makeText(this, "Enable 'Scroller Service' in Accessibility Settings", Toast.LENGTH_LONG).show()
    }
    
    private fun startScrollerService() {
        val intent = Intent(this, OverlayService::class.java)
        startForegroundService(intent)
        Toast.makeText(this, "Scroller service started", Toast.LENGTH_SHORT).show()
    }
    
    private fun stopScrollerService() {
        val intent = Intent(this, OverlayService::class.java)
        stopService(intent)
        Toast.makeText(this, "Scroller service stopped", Toast.LENGTH_SHORT).show()
    }
    
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQUEST_OVERLAY_PERMISSION -> {
                updatePermissionStatus()
            }
        }
    }
    
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            REQUEST_NOTIFICATION_PERMISSION -> {
                updatePermissionStatus()
            }
        }
    }
    
    override fun onResume() {
        super.onResume()
        updatePermissionStatus()
    }
}