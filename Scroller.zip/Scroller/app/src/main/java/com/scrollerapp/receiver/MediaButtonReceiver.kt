package com.scrollerapp.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.view.KeyEvent
import androidx.preference.PreferenceManager
import com.scrollerapp.service.OverlayService

class MediaButtonReceiver : BroadcastReceiver() {
    
    companion object {
        private const val PREF_VOLUME_UP_ACTION = "volume_up_action"
        private const val PREF_VOLUME_DOWN_ACTION = "volume_down_action"
        private const val PREF_PLAY_PAUSE_ACTION = "play_pause_action"
        
        private const val ACTION_SCROLL_UP = "scroll_up"
        private const val ACTION_SCROLL_DOWN = "scroll_down"
        private const val ACTION_TOGGLE_OVERLAY = "toggle_overlay"
        private const val ACTION_NONE = "none"
        
        // Debounce timing to prevent rapid-fire events
        private var lastButtonPressTime = 0L
        private const val BUTTON_DEBOUNCE_TIME = 200L
    }
    
    override fun onReceive(context: Context?, intent: Intent?) {
        if (context == null || intent == null) return
        
        // Check if this is a media button event
        if (Intent.ACTION_MEDIA_BUTTON == intent.action) {
            val keyEvent = intent.getParcelableExtra<KeyEvent>(Intent.EXTRA_KEY_EVENT)
            keyEvent?.let { event ->
                if (event.action == KeyEvent.ACTION_DOWN) {
                    handleMediaButton(context, event.keyCode)
                }
            }
        }
    }
    
    private fun handleMediaButton(context: Context, keyCode: Int) {
        // Debounce button presses
        val currentTime = System.currentTimeMillis()
        if (currentTime - lastButtonPressTime < BUTTON_DEBOUNCE_TIME) {
            return
        }
        lastButtonPressTime = currentTime
        
        val prefs = PreferenceManager.getDefaultSharedPreferences(context)
        val action = when (keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> prefs.getString(PREF_VOLUME_UP_ACTION, ACTION_SCROLL_UP)
            KeyEvent.KEYCODE_VOLUME_DOWN -> prefs.getString(PREF_VOLUME_DOWN_ACTION, ACTION_SCROLL_DOWN)
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> prefs.getString(PREF_PLAY_PAUSE_ACTION, ACTION_TOGGLE_OVERLAY)
            KeyEvent.KEYCODE_MEDIA_NEXT -> ACTION_SCROLL_DOWN
            KeyEvent.KEYCODE_MEDIA_PREVIOUS -> ACTION_SCROLL_UP
            else -> ACTION_NONE
        }
        
        executeAction(context, action)
    }
    
    private fun executeAction(context: Context, action: String?) {
        val serviceIntent = Intent(context, OverlayService::class.java)
        
        when (action) {
            ACTION_SCROLL_UP -> {
                serviceIntent.action = OverlayService.ACTION_SCROLL_UP
                context.startForegroundService(serviceIntent)
            }
            ACTION_SCROLL_DOWN -> {
                serviceIntent.action = OverlayService.ACTION_SCROLL_DOWN
                context.startForegroundService(serviceIntent)
            }
            ACTION_TOGGLE_OVERLAY -> {
                serviceIntent.action = OverlayService.ACTION_TOGGLE_OVERLAY
                context.startForegroundService(serviceIntent)
            }
        }
    }
}