package com.scrollerapp.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.graphics.Path
import android.graphics.PointF
import android.view.accessibility.AccessibilityEvent
import androidx.preference.PreferenceManager

class ScrollAccessibilityService : AccessibilityService() {
    
    private lateinit var scrollReceiver: BroadcastReceiver
    private lateinit var prefs: SharedPreferences
    
    companion object {
        private const val PREF_SCROLL_SPEED = "scroll_speed"
        private const val PREF_SCROLL_DISTANCE = "scroll_distance"
        private const val DEFAULT_SCROLL_SPEED = 300L // milliseconds
        private const val DEFAULT_SCROLL_DISTANCE = 200 // pixels
    }
    
    override fun onServiceConnected() {
        super.onServiceConnected()
        prefs = PreferenceManager.getDefaultSharedPreferences(this)
        registerScrollReceiver()
    }
    
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // We don't need to handle accessibility events for this use case
        // The service is primarily used for gesture injection
    }
    
    override fun onInterrupt() {
        // Handle service interruption if needed
    }
    
    private fun registerScrollReceiver() {
        scrollReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                if (intent?.action == "com.scrollerapp.PERFORM_SCROLL") {
                    val scrollUp = intent.getBooleanExtra("scroll_up", true)
                    performScroll(scrollUp)
                }
            }
        }
        
        val filter = IntentFilter("com.scrollerapp.PERFORM_SCROLL")
        registerReceiver(scrollReceiver, filter)
    }
    
    private fun performScroll(scrollUp: Boolean) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            val displayMetrics = resources.displayMetrics
            val screenWidth = displayMetrics.widthPixels
            val screenHeight = displayMetrics.heightPixels
            
            // Get scroll settings
            val scrollDistance = prefs.getInt(PREF_SCROLL_DISTANCE, DEFAULT_SCROLL_DISTANCE)
            val scrollSpeed = prefs.getLong(PREF_SCROLL_SPEED, DEFAULT_SCROLL_SPEED)
            
            // Calculate scroll path
            val startX = screenWidth / 2f
            val startY = screenHeight / 2f
            val endY = if (scrollUp) {
                startY - scrollDistance
            } else {
                startY + scrollDistance
            }
            
            // Create gesture path
            val path = Path().apply {
                moveTo(startX, startY)
                lineTo(startX, endY)
            }
            
            // Create gesture description
            val gestureBuilder = GestureDescription.Builder()
            val strokeDescription = GestureDescription.StrokeDescription(path, 0, scrollSpeed)
            gestureBuilder.addStroke(strokeDescription)
            
            // Dispatch gesture
            val gesture = gestureBuilder.build()
            dispatchGesture(gesture, object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    super.onCompleted(gestureDescription)
                    // Gesture completed successfully
                }
                
                override fun onCancelled(gestureDescription: GestureDescription?) {
                    super.onCancelled(gestureDescription)
                    // Gesture was cancelled
                }
            }, null)
        } else {
            // For older Android versions, try alternative scroll methods
            performLegacyScroll(scrollUp)
        }
    }
    
    @Suppress("DEPRECATION")
    private fun performLegacyScroll(scrollUp: Boolean) {
        // For Android versions below N, use global actions
        val action = if (scrollUp) {
            // Try to find scrollable node and perform scroll up
            rootInActiveWindow?.let { root ->
                findScrollableNode(root)?.performAction(
                    if (scrollUp) {
                        android.view.accessibility.AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
                    } else {
                        android.view.accessibility.AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                    }
                )
            }
        } else {
            rootInActiveWindow?.let { root ->
                findScrollableNode(root)?.performAction(
                    android.view.accessibility.AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                )
            }
        }
    }
    
    private fun findScrollableNode(node: android.view.accessibility.AccessibilityNodeInfo?): android.view.accessibility.AccessibilityNodeInfo? {
        if (node == null) return null
        
        if (node.isScrollable) {
            return node
        }
        
        for (i in 0 until node.childCount) {
            val child = node.getChild(i)
            val scrollable = findScrollableNode(child)
            if (scrollable != null) {
                return scrollable
            }
        }
        
        return null
    }
    
    override fun onDestroy() {
        super.onDestroy()
        if (::scrollReceiver.isInitialized) {
            unregisterReceiver(scrollReceiver)
        }
    }
}